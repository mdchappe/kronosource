-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Host: db491689781.db.1and1.com
-- Generation Time: Jan 29, 2014 at 12:22 AM
-- Server version: 5.1.73
-- PHP Version: 5.3.3-7+squeeze18
-- 
-- Database: `db491689781`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `captcha`
-- 

CREATE TABLE `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `word` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=44 ;

-- 
-- Dumping data for table `captcha`
-- 

INSERT INTO `captcha` VALUES (26, 1390963207, '50.87.144.18', 'XkBAqiSC');
INSERT INTO `captcha` VALUES (25, 1390948801, '23.29.119.226', 'D4AI7kNn');
INSERT INTO `captcha` VALUES (24, 1390948697, '63.92.247.89', '4VwcrD7o');
INSERT INTO `captcha` VALUES (23, 1390948568, '23.29.119.226', 'NnuKnm6M');
INSERT INTO `captcha` VALUES (5, 1390942570, '76.186.151.54', 'hxwbfhq8');
INSERT INTO `captcha` VALUES (6, 1390943015, '76.186.151.54', 'ZLjsZfWb');
INSERT INTO `captcha` VALUES (7, 1390943602, '76.186.151.54', '7JmwrhBP');
INSERT INTO `captcha` VALUES (8, 1390943646, '76.186.151.54', 'B7OYaLzV');
INSERT INTO `captcha` VALUES (9, 1390945830, '23.29.119.226', 'zPDg6qT3');
INSERT INTO `captcha` VALUES (10, 1390945943, '23.29.119.226', 'vfdQy7Kl');
INSERT INTO `captcha` VALUES (11, 1390946595, '23.29.119.226', '4nfNSnWu');
INSERT INTO `captcha` VALUES (12, 1390946659, '23.29.119.226', 'J2rIiOmF');
INSERT INTO `captcha` VALUES (13, 1390946799, '23.29.119.226', 'F2VtUPTH');
INSERT INTO `captcha` VALUES (14, 1390946991, '23.29.119.226', 'lMQsTFPC');
INSERT INTO `captcha` VALUES (15, 1390947033, '23.29.119.226', 'kl7xXMLy');
INSERT INTO `captcha` VALUES (16, 1390947170, '23.29.119.226', 'TQuPCVRH');
INSERT INTO `captcha` VALUES (17, 1390947285, '23.29.119.226', 'UfXO5rqg');
INSERT INTO `captcha` VALUES (18, 1390947295, '23.29.119.226', 'Iy30IzgE');
INSERT INTO `captcha` VALUES (19, 1390947322, '23.29.119.226', '2hTyYcQo');
INSERT INTO `captcha` VALUES (20, 1390947381, '23.29.119.226', 'Hs2JwmUY');
INSERT INTO `captcha` VALUES (21, 1390947397, '23.29.119.226', 'GtM8Joni');
INSERT INTO `captcha` VALUES (22, 1390948421, '23.29.119.226', 'gRiYrGuv');
INSERT INTO `captcha` VALUES (27, 1390968765, '173.74.235.92', 'ldQnw8UA');
INSERT INTO `captcha` VALUES (28, 1390969341, '173.74.235.92', 'Ig0Zg2eb');
INSERT INTO `captcha` VALUES (29, 1390969350, '173.74.235.92', 'NFUZBOtj');
INSERT INTO `captcha` VALUES (30, 1390969376, '173.74.235.92', 'SRmrvs82');
INSERT INTO `captcha` VALUES (31, 1390969401, '173.74.235.92', 'ZXgtM6gX');
INSERT INTO `captcha` VALUES (32, 1390969832, '173.74.235.92', 'HZ2LL5GA');
INSERT INTO `captcha` VALUES (33, 1390969891, '173.74.235.92', '4J5XHYEc');
INSERT INTO `captcha` VALUES (34, 1390969948, '173.74.235.92', 'gdd6uJyk');
INSERT INTO `captcha` VALUES (35, 1390974369, '162.213.197.14', 'ot1Vwc2w');
INSERT INTO `captcha` VALUES (36, 1390974534, '162.213.197.14', 'lKgAFSoA');
INSERT INTO `captcha` VALUES (37, 1390974726, '162.213.197.14', '6T9dSini');
INSERT INTO `captcha` VALUES (38, 1390975044, '162.213.197.14', '7f4tCEP9');
INSERT INTO `captcha` VALUES (39, 1390975186, '173.74.235.92', 'qNo42IJw');
INSERT INTO `captcha` VALUES (40, 1390975637, '173.74.235.92', 'CBvc5nna');
INSERT INTO `captcha` VALUES (41, 1390975840, '4.53.51.197', 'a5Au3j0V');
INSERT INTO `captcha` VALUES (42, 1390976374, '173.74.235.92', 'DuktjCQe');
INSERT INTO `captcha` VALUES (43, 1390976432, '173.74.235.92', 'zZd5qjDm');

-- --------------------------------------------------------

-- 
-- Table structure for table `complex_example`
-- 

CREATE TABLE `complex_example` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `complex_example`
-- 

INSERT INTO `complex_example` VALUES (1, 'Pleasant Pines', '123 Four St.', 'Best. Complex. Evar.');
INSERT INTO `complex_example` VALUES (2, 'Shady Shadetrees', '342 One St.', 'Worst. Complex. Today. And Tomorrow.');
INSERT INTO `complex_example` VALUES (3, 'Grover''s Grove', '1010 Bigfake St.', 'The apartments are really complex.');
INSERT INTO `complex_example` VALUES (4, 'Concrete Falls', '329 Nature Tr.', 'Anything falls if you drop it like a bad habit.');
INSERT INTO `complex_example` VALUES (5, 'Obsequious Glen', '666 Happy Happy Rd.', 'Do you have any idea what you''re getting into? Didn''t think so.');
INSERT INTO `complex_example` VALUES (9, 'Heavenly Forests', '1891 Froggy St.', 'Make us your home living destination of choice for now and forever!');

-- --------------------------------------------------------

-- 
-- Table structure for table `groups`
-- 

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `groups`
-- 

INSERT INTO `groups` VALUES (1, 'admin', 'Administrator');
INSERT INTO `groups` VALUES (2, 'locator', 'Apartment Locator');
INSERT INTO `groups` VALUES (3, 'property', 'Property');

-- --------------------------------------------------------

-- 
-- Table structure for table `login_attempts`
-- 

CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `login_attempts`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `message_traffic`
-- 

CREATE TABLE `message_traffic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `from` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `to_id` int(11) NOT NULL,
  `to` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT '0',
  `display` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `message_traffic`
-- 

INSERT INTO `message_traffic` VALUES (1, 2, 8, 'John Doe', 15, 'FakeTown', 0, 1);
INSERT INTO `message_traffic` VALUES (2, 3, 8, 'John Doe', 15, 'FakeTown', 0, 1);
INSERT INTO `message_traffic` VALUES (3, 5, 15, 'FakeTown', 8, 'John Doe', 1, 0);
INSERT INTO `message_traffic` VALUES (4, 6, 15, 'FakeTown', 8, 'John Doe', 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `messages`
-- 

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT 'new message',
  `message` text COLLATE latin1_general_ci NOT NULL,
  `sent_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `messages`
-- 

INSERT INTO `messages` VALUES (1, 'Hi there!', 'DId you know I like cheese?  I like it a lot.', '2014-01-23');
INSERT INTO `messages` VALUES (2, 'This is a test.', 'It is only a test.', '2014-01-23');
INSERT INTO `messages` VALUES (3, 'Time to clutter up the database.', 'I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-23');
INSERT INTO `messages` VALUES (4, 'Re: Time to clutter up the database.', 'Good to know.  Thanks for the heads up.\n\nRegards,\n  FakeTown\n----------------------------------\n				I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-28');
INSERT INTO `messages` VALUES (5, 'Re: Time to clutter up the database.', 'Good to know.  Thanks for the heads up.\n\nRegards,\n  FakeTown\n----------------------------------\n				I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-28');
INSERT INTO `messages` VALUES (6, 'Re: This is a test.', 'Test test test. Testy testy test.\n----------------------------------\n				It is only a test.', '2014-01-28');

-- --------------------------------------------------------

-- 
-- Table structure for table `property`
-- 

CREATE TABLE `property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `management` tinytext COLLATE latin1_general_ci NOT NULL,
  `property_id` int(11) NOT NULL,
  `fitness` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `dog_park` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `clubhouse` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `blinds` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `ceilings` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `pool` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `laundry` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `business` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `wifi` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `gated` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `cable` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `fireplace` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `elevator` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `storage` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `parking` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `trash` enum('valet','dumpster','trash chute') COLLATE latin1_general_ci NOT NULL,
  `court` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `dog` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `cat` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `property`
-- 

INSERT INTO `property` VALUES (1, 'Fake Properties, Inc.', 15, '0', 'Dog Park', 'Clubhouse', '2-inch Wood Blinds', 'Vaulted Ceilings', '0', 'On-Site Laundry', '0', '0', 'Gated Community', 'TeeVee Cable Co', 'Fireplace', '0', '0', '0', 'valet', '0', 'Dogs', 'Cats');
INSERT INTO `property` VALUES (2, '', 19, '0', '0', '0', '0', '0', '0', '0', '0', 'Free Wifi', '0', 'AT&T', '0', '0', 'Storage Available', 'Reserved Parking', 'valet', '0', '0', '0');
INSERT INTO `property` VALUES (3, '', 20, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', '0', '0', '0', 'Time Warner', '0', '0', 'Storage Available', '0', 'valet', 'Sports Courts', '0', '0');
INSERT INTO `property` VALUES (4, '', 21, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', 'Business Center', '0', '0', 'AT&T', '0', '0', '0', '0', 'valet', '0', '0', '0');
INSERT INTO `property` VALUES (5, '', 22, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', '0', 'Free Wifi', '0', 'Time Warner', 'Fireplace', '0', '0', '0', 'valet', '0', '0', '0');

-- --------------------------------------------------------

-- 
-- Table structure for table `registration_codes`
-- 

CREATE TABLE `registration_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `usertype` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  UNIQUE KEY `id` (`id`,`code`),
  KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `registration_codes`
-- 

INSERT INTO `registration_codes` VALUES (1, 'locator', 'locator', 1);
INSERT INTO `registration_codes` VALUES (2, 'property', 'property', 1);
INSERT INTO `registration_codes` VALUES (3, 'oldcode', 'locator', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `rent`
-- 

CREATE TABLE `rent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `term` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `rent` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `deposit` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `pet_rent` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `pet_deposit` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `rent`
-- 

INSERT INTO `rent` VALUES (2, 1, '6 months', '$5000', '6 months', 'n/a', '$1');
INSERT INTO `rent` VALUES (3, 2, '1 month', '$1,000,000', '$1', '$2', '$50');
INSERT INTO `rent` VALUES (4, 3, '10 years', '$20', '$1,000', 'n/a', 'n/a');
INSERT INTO `rent` VALUES (5, 4, '1 month', '$1,000,000', '$1,000', '$500', '$5,000');
INSERT INTO `rent` VALUES (6, 4, '1 year', '$900,000', '$3,000', '$2,108', '$3,000');

-- --------------------------------------------------------

-- 
-- Table structure for table `unit`
-- 

CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `beds` varchar(4) COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `baths` varchar(4) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `size` smallint(6) NOT NULL,
  `direction` enum('N','NE','E','SE','S','SW','W','NW') COLLATE latin1_general_ci DEFAULT NULL,
  `date_available` date DEFAULT NULL,
  `commission` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `requirements` text COLLATE latin1_general_ci,
  `specials` text COLLATE latin1_general_ci,
  `washer` enum('none','connection','side by side','stacked') COLLATE latin1_general_ci DEFAULT NULL,
  `furnished` tinyint(1) DEFAULT NULL,
  `floor` smallint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `unit`
-- 

INSERT INTO `unit` VALUES (1, 15, 'The Broom', '1', '0', 100, 'N', '2013-11-15', '1%', 'Must be cool.', '', 'none', 1, 1);
INSERT INTO `unit` VALUES (2, 15, 'The Other Closet', '1', '0', 101, 'N', '2013-11-12', '100%', 'nope', '', 'none', 1, 1);
INSERT INTO `unit` VALUES (3, 15, 'It''s Like Closet Town Over Here', '1', '0', 57, 'SW', '2013-11-30', 'none', 'Must like small spaces.', 'First year free!', 'stacked', 0, 1);
INSERT INTO `unit` VALUES (4, 15, 'Surprise! A cavern!', '1', '0', 10, 'W', '2013-11-11', '$1', '', '', '', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `display_name` varchar(128) NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `street` varchar(128) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `state` tinytext,
  `zip` varchar(10) DEFAULT NULL,
  `file_name` varchar(128) NOT NULL DEFAULT '/assets/img/profile/none.jpg',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 0x7fefbfbdefbfbd, 'administrator', '59beecdf7fc966e2f17fd8f65a4a9aeb09d4a3d4', '9462e8eee0', 'admin@admin.com', '', NULL, NULL, '9d029802e28cd9c768e8e62277c0df49ec65c48c', 1268889823, 1380643465, 1, 'Admin', 'istrator', '', 'ADMIN', '0', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (2, 0x4cefbfbdefbfbd36, 'johnny', 'd62fd2a8a4f98cd0524f2fc9553b876e8df47c4f', NULL, 'johnny@johnny.com', NULL, NULL, NULL, 'b221f49ab578223a1b799f7264cf3f1bb7b6f8c2', 1380515223, 1380515244, 1, 'Johnny', 'Bravo', '', 'none', '972-835-5000', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (3, 0x4cefbfbdefbfbd36, 'heisenberg', '51e3a3150ae4e89579d586e1058fc21cc2706a56', NULL, 'heisenberg@example.com', NULL, NULL, NULL, NULL, 1380515501, 1380515501, 1, 'Heisenberg', 'Heisenberg', '', '', '123-456-0987', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (4, 0x4cefbfbdefbfbd36, 'pinkman', '64bf1d8284cdae2c48f0466dccfefabfdd31013f', NULL, 'pinkman@example.com', NULL, NULL, NULL, NULL, 1380515717, 1380515717, 1, 'Jesse', 'Pinkman', '', 'PinkCo', '321-847-2840', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (5, 0x4cefbfbdefbfbd36, 'walterjr', '58d4e87de581463b8ddca339993b35d8c1f95f9c', NULL, 'walterjr@example.com', NULL, NULL, NULL, 'b7cdef3459f844a75003349d9c50a4a373797fe3', 1380515972, 1380515993, 1, 'Walter', 'White', '', '', '391-382-4850', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (6, 0x4cefbfbdefbfbd36, 'skinnypete', 'b6e805de50e83053e1dfff64dd506e7c8880bfb2', NULL, 'skinnyp@example.com', NULL, NULL, NULL, 'fceac7cce28bfd38cdc8b41e2601911d9f50d90c', 1380516602, 1380516617, 1, 'Skinny', 'Pete', '', '', '582-430-8740', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (7, 0x4cefbfbdefbfbd36, 'krazyeight', '71f82bcf7ec776e75f93f6d986a202fde88dfdea', NULL, 'kr8zy@example.com', NULL, NULL, NULL, NULL, 1380516789, 1380516789, 1, 'Krazy', 'Eight', '', '', '471-480-2918', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (8, 0x4cefbfbdefbfbd36, 'username', '28409b3ce4adf8670247fa517e9c70a16ae5be36', NULL, 'user@example.com', NULL, NULL, NULL, '62c1391963332c485e017d4d8c0c9a369248f8bc', 1380516909, 1390976432, 1, 'User', 'Name', 'John Doe', 'UserCo, Ltd.', '743-184-1234', '', '', '', '', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (9, 0xefbfbdefbfbdefbfbd7c, 'shadypines', '999184d6dfd5d0fc09aab85e3d8cafe50240175f', NULL, 'shadypines@example.com', NULL, NULL, NULL, 'a1fb972ee913a079a9115435d9482481b775a74d', 1380556231, 1380739230, 1, 'Bob', 'Johnson', '', 'Shady Pines', '478-482-4095', '123 Four St.', 'Dallas', 'TX', '75000', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (10, 0xefbfbdefbfbdefbfbd7c, 'sandysands', '53b26389e63586bf155dd32d0891caaf711b1deb', NULL, 'sandysands@example.com', NULL, NULL, NULL, 'b58fd258a400fb39bef2978e9c53e179b5d78b73', 1380556596, 1380641693, 1, 'Sandra', 'Sands', '', 'Sandy Sands', '734-128-5837', '432 One St.', 'Plano', 'TX', '75024', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (15, 0x4cefbfbdefbfbd36, 'fakeuser', '5f3b0cdabef77ca7b5e7c4a38abdb67f32f13d33', NULL, 'fake@example.com', NULL, NULL, NULL, '1e830dc0176f1938d9fd0dd5cdb0df8b7a12744a', 1380955301, 1390932354, 1, 'Billy', 'Robertson', 'FakeTown', 'FakeTown', '123-456-7890', '4729 That St', 'Dallas', 'tx', '12345', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (17, 0x4cefbfbdefbfbd36, 'apartment', '15b071cf8fc3bcd01bc858e0d6bbb74af0828125', NULL, 'apartment@example.com', NULL, NULL, NULL, '91b9dcbb33690dbc02004e8ab6afeaa0e1db7dac', 1386735290, 1386735290, 1, 'Apartmenty', 'McApartmentson', '', 'Apartment', '972-123-4567', '123 Some St.', 'Plano', 'tx', '75023', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (18, 0x4cefbfbdefbfbd36, 'test_apartment', '01eb2fb833f3fcee2b77c1dab4d00ce63ff61696', NULL, 'test_apartment@example.com', NULL, NULL, NULL, 'eccfec2983a8ed4b9405d46b582f3ebb3270da63', 1386735986, 1386735986, 1, 'Test', 'Apartment', '', 'Test Apartment', '972-123-4567', '123 Some St.', 'Dallas', 'tx', '75123', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (19, 0x4cefbfbdefbfbd36, 'testProperty', '8d062551db7afb6d7428ee3f41104036b5a532b4', NULL, 'testproperty2@example.com', NULL, NULL, NULL, '66b233c252ac4a38a06c15ab2a5ceec4ec3f12fb', 1386736479, 1386736479, 1, 'Test', 'Property', '', 'Test Property', '972-123-4567', '1456 Mockingbird Ln.', 'Dallas', 'tx', '75123', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (20, 0x4cefbfbdefbfbd36, 'testProperty3', 'b1cd36fb3444910279fb4ebcd385e8ede81d8d1b', NULL, 'testproperty3@example.com', NULL, NULL, NULL, '1602d5ac104d26bb5ab848e489166421172d2a20', 1386737016, 1386737016, 1, 'Test', 'PropertyThree', '', 'Test Property 3', '972-485-1385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (21, 0x4cefbfbdefbfbd36, 'testProperty4', '86cc8797a2fecfd9f52d773c36e104b44a6c3269', NULL, 'testproperty4@example.com', NULL, NULL, NULL, 'f4b0b5e1cf8bb0d9f8aac88ad7c18770dddbf2dd', 1386737753, 1386737753, 1, 'Test', 'PropertyFour', '', 'Test Property 4', '9724851385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/none.jpg');
INSERT INTO `users` VALUES (22, 0x4cefbfbdefbfbd36, 'testProperty5', '7fdafca5d680b923b571ca13bf6e5af1e13d636f', NULL, 'testproperty5@example.com', NULL, NULL, NULL, 'a2ba38aa03aed550ccdf12de92ca928b61097104', 1386738850, 1386782473, 1, 'Test', 'PropertyFive', '', 'Test Property 5', '9724851385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/0be2d990f7a23328c15da76a6acd07b6.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `users_groups`
-- 

CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `users_groups`
-- 

INSERT INTO `users_groups` VALUES (1, 1, 1);
INSERT INTO `users_groups` VALUES (2, 1, 2);
INSERT INTO `users_groups` VALUES (3, 2, 2);
INSERT INTO `users_groups` VALUES (4, 3, 2);
INSERT INTO `users_groups` VALUES (5, 4, 2);
INSERT INTO `users_groups` VALUES (6, 5, 2);
INSERT INTO `users_groups` VALUES (7, 6, 2);
INSERT INTO `users_groups` VALUES (8, 7, 2);
INSERT INTO `users_groups` VALUES (9, 8, 2);
INSERT INTO `users_groups` VALUES (10, 9, 3);
INSERT INTO `users_groups` VALUES (11, 10, 3);
INSERT INTO `users_groups` VALUES (16, 15, 3);
INSERT INTO `users_groups` VALUES (18, 17, 3);
INSERT INTO `users_groups` VALUES (19, 18, 3);
INSERT INTO `users_groups` VALUES (20, 19, 3);
INSERT INTO `users_groups` VALUES (21, 20, 3);
INSERT INTO `users_groups` VALUES (22, 21, 3);
INSERT INTO `users_groups` VALUES (23, 22, 3);

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `users_groups`
-- 
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
