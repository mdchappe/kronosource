-- phpMyAdmin SQL Dump
-- version 4.0.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 10, 2014 at 11:23 PM
-- Server version: 5.5.33
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db491689781`
--

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `word` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=171 ;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(105, 1391056404, '::1', 'fkLz1ryT'),
(104, 1391056402, '::1', 'h3PTHl5B'),
(103, 1391038575, '::1', 'JBCHrnh6'),
(102, 1391038569, '::1', 'vkXA7YVZ'),
(101, 1391037757, '::1', 'LjWG6r9o'),
(100, 1391037729, '::1', '0n6rDxLK'),
(99, 1391037588, '::1', 'hcO4MZ7i'),
(98, 1391037382, '::1', 'EXuaPvem'),
(97, 1391037306, '::1', 'w2Qpc3Tm'),
(96, 1391037276, '::1', 'fl3gqhDB'),
(95, 1391037252, '::1', 'qxYpETXM'),
(94, 1391037225, '::1', 'YfRG0G4Y'),
(93, 1391037176, '::1', 'Ll72K4yg'),
(92, 1391036840, '::1', '3wiwjYSs'),
(91, 1391036773, '::1', 'I3IQd3aB'),
(90, 1391036192, '::1', 'KWi7cMF2'),
(89, 1391036170, '::1', 'o2gPJqUJ'),
(88, 1391036157, '::1', 'h4VVnYUg'),
(87, 1391036081, '::1', '9AxI3tbs'),
(86, 1391036051, '::1', 'CYwIdtsO'),
(85, 1391035993, '::1', 'qO7OPa1T'),
(84, 1391035980, '::1', 'XsFmMJzS'),
(83, 1391035942, '::1', 'FM8orWLA'),
(82, 1391035909, '::1', 'Qt1iz8uM'),
(81, 1391035866, '::1', 'YZBlRFcm'),
(80, 1391035527, '::1', 'bHHSraqC'),
(79, 1391035478, '::1', 'LrpRWSN9'),
(78, 1391035419, '::1', 'XsQPzf1P'),
(77, 1391035370, '::1', 'bjrkR5jM'),
(76, 1391035339, '::1', '97Fw0anO'),
(75, 1391035265, '::1', '0zXqpQQn'),
(74, 1391034920, '::1', 'GsFdEFkn'),
(73, 1391034846, '::1', 'dVQ232Ka'),
(72, 1391034801, '::1', 'qIwhbAtC'),
(71, 1391034751, '::1', 'mfR6arec'),
(70, 1391034471, '::1', 'KwLLCjEv'),
(69, 1391034347, '::1', 'RdgzYPIq'),
(68, 1391034193, '::1', 'Di1hZRQz'),
(67, 1391034191, '::1', 'jKOUiyBH'),
(66, 1391034189, '::1', 'XKlt85eH'),
(65, 1391034133, '::1', 'uYsABr01'),
(64, 1391034022, '::1', 'elFM5AzC'),
(63, 1391033935, '::1', 'TSZtfujF'),
(62, 1391029207, '::1', '1dST9rQ1'),
(61, 1391029198, '::1', 'mBhJAIm5'),
(60, 1391028234, '::1', '4Vkx3BKa'),
(59, 1391024875, '::1', 'Vck7cRD9'),
(58, 1391024819, '::1', 'fTZrWxxg'),
(57, 1391024642, '::1', 'y24yQ9uJ'),
(56, 1391022831, '::1', 'ALM7QLE7'),
(55, 1391022754, '::1', 'GYA3T5yk'),
(106, 1391056410, '::1', 'toJB9vUJ'),
(107, 1391060118, '::1', 'rZqTpxOZ'),
(108, 1391060304, '::1', 'ehVQXr8l'),
(109, 1391128402, '::1', 'bN6Daloc'),
(110, 1391128413, '::1', 'oCygNrkW'),
(111, 1391128429, '::1', 'rk5VtK6H'),
(112, 1391128471, '::1', 'BJ0yTXlI'),
(113, 1391128511, '::1', 'Ckx8lOCf'),
(114, 1391209500, '::1', 'CgH1xvsI'),
(115, 1391209518, '::1', 'hY5nY02B'),
(116, 1391209576, '::1', 'u0cEZQwQ'),
(117, 1391222774, '::1', 'LgZK14ZA'),
(118, 1391223493, '::1', 'fALVGx9p'),
(119, 1391223502, '::1', 'Dy7vs1tq'),
(120, 1391223575, '::1', 'VFy17YQr'),
(121, 1391224088, '::1', '1kSQa43R'),
(122, 1391224091, '::1', 'YKo9MQaB'),
(123, 1391224096, '::1', 'wTtWM6sQ'),
(124, 1391224114, '::1', 'RZ0m7Vpl'),
(125, 1391224202, '::1', 'k7EmYddQ'),
(126, 1391224210, '::1', '00v8rJob'),
(127, 1391224293, '::1', 'w44V83Lx'),
(128, 1391224304, '::1', 'vQCr6N3y'),
(129, 1391224345, '::1', '5Oz5N4YU'),
(130, 1391224478, '::1', 'BbSkX1SI'),
(131, 1391224482, '::1', 'VvBEzEe1'),
(132, 1391224679, '::1', 'OVS93OpJ'),
(133, 1391224681, '::1', 'G9y4Kcdv'),
(134, 1391224819, '::1', 'KqUNEnPt'),
(135, 1391224838, '::1', 'czw20M5I'),
(136, 1391224840, '::1', 'B3NrQuxa'),
(137, 1391224846, '::1', '67hWXJ97'),
(138, 1391224859, '::1', 'E1eD77me'),
(139, 1391224957, '::1', '2sTfdC2I'),
(140, 1391224963, '::1', '05PurzU6'),
(141, 1391226243, '::1', 'B8OpXFuu'),
(142, 1391226249, '::1', '4SJUdw24'),
(143, 1391226348, '::1', 'RCFNXSbi'),
(144, 1391226423, '::1', 'wtEIBk6O'),
(145, 1391226427, '::1', 'RvYl7Fv5'),
(146, 1391226498, '::1', 'dzSsPkeK'),
(147, 1391226625, '::1', 'UnX9Mhgf'),
(148, 1391226627, '::1', 'I3nmjte3'),
(149, 1391226723, '::1', 'r3xKwkpM'),
(150, 1391226808, '::1', 'drkCpkcy'),
(151, 1391226930, '::1', 'P6IgWx8z'),
(152, 1391228372, '::1', '3soXJ1Hq'),
(153, 1391228377, '::1', '18f5BBgR'),
(154, 1391229013, '::1', 'cwgqehia'),
(155, 1391229017, '::1', 'suQ98i6A'),
(156, 1391377968, '::1', 'c269sGBg'),
(157, 1391378249, '::1', '3DEuPBDH'),
(158, 1391378463, '::1', 'Li02rkVw'),
(159, 1391378476, '::1', 'mHCj52Li'),
(160, 1391378500, '::1', 'svfWzyPM'),
(161, 1391378501, '::1', 'P5DPUsQ2'),
(162, 1391378503, '::1', 'a2cBHUuq'),
(163, 1391378510, '::1', 'a9XFcGez'),
(164, 1391378519, '::1', 'iIqJmSIw'),
(165, 1391378730, '::1', 'MoyfWkQx'),
(166, 1391378748, '::1', 'KNwUpbk6'),
(167, 1391378776, '::1', 'bkK73voF'),
(168, 1391378791, '::1', 'UgbBKbrZ'),
(169, 1391378991, '::1', 'qHPNAvxB'),
(170, 1391379451, '::1', 'liiJp8sZ');

-- --------------------------------------------------------

--
-- Table structure for table `complex_example`
--

CREATE TABLE `complex_example` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `complex_example`
--

INSERT INTO `complex_example` (`id`, `name`, `address`, `description`) VALUES
(1, 'Pleasant Pines', '123 Four St.', 'Best. Complex. Evar.'),
(2, 'Shady Shadetrees', '342 One St.', 'Worst. Complex. Today. And Tomorrow.'),
(3, 'Grover''s Grove', '1010 Bigfake St.', 'The apartments are really complex.'),
(4, 'Concrete Falls', '329 Nature Tr.', 'Anything falls if you drop it like a bad habit.'),
(5, 'Obsequious Glen', '666 Happy Happy Rd.', 'Do you have any idea what you''re getting into? Didn''t think so.'),
(9, 'Heavenly Forests', '1891 Froggy St.', 'Make us your home living destination of choice for now and forever!');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'locator', 'Apartment Locator'),
(3, 'property', 'Property');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT 'new message',
  `message` text COLLATE latin1_general_ci NOT NULL,
  `sent_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `subject`, `message`, `sent_on`) VALUES
(1, 'Hi there!', 'DId you know I like cheese?  I like it a lot.', '2014-01-23'),
(2, 'This is a test.', 'It is only a test.', '2014-01-23'),
(3, 'Time to clutter up the database.', 'I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-23'),
(4, 'Re: Time to clutter up the database.', 'Good to know.  Thanks for the heads up.\n\nRegards,\n  FakeTown\n----------------------------------\n				I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-28'),
(5, 'Re: Time to clutter up the database.', 'Good to know.  Thanks for the heads up.\n\nRegards,\n  FakeTown\n----------------------------------\n				I''m going to do it by sending a crap-ton of test messages like this one.', '2014-01-28'),
(6, 'Re: This is a test.', 'Test test test. Testy testy test.\n----------------------------------\n				It is only a test.', '2014-01-28');

-- --------------------------------------------------------

--
-- Table structure for table `message_traffic`
--

CREATE TABLE `message_traffic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `from` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `to_id` int(11) NOT NULL,
  `to` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT '0',
  `display` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `message_traffic`
--

INSERT INTO `message_traffic` (`id`, `message_id`, `from_id`, `from`, `to_id`, `to`, `read`, `display`) VALUES
(1, 2, 8, 'John Doe', 15, 'FakeTown', 0, 1),
(2, 3, 8, 'John Doe', 15, 'FakeTown', 0, 1),
(3, 5, 15, 'FakeTown', 8, 'John Doe', 1, 0),
(4, 6, 15, 'FakeTown', 8, 'John Doe', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated` int(11) NOT NULL,
  `management` tinytext COLLATE latin1_general_ci NOT NULL,
  `property_id` int(11) NOT NULL,
  `fitness` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `dog_park` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `clubhouse` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `blinds` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `ceilings` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `pool` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `laundry` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `business` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `wifi` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `gated` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `cable` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `fireplace` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `elevator` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `storage` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `parking` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `trash` enum('valet','dumpster','trash chute') COLLATE latin1_general_ci NOT NULL,
  `court` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `dog` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `cat` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `updated`, `management`, `property_id`, `fitness`, `dog_park`, `clubhouse`, `blinds`, `ceilings`, `pool`, `laundry`, `business`, `wifi`, `gated`, `cable`, `fireplace`, `elevator`, `storage`, `parking`, `trash`, `court`, `dog`, `cat`) VALUES
(1, 1391996132, 'Fake Properties, Inc.', 15, '0', 'Dog Park', 'Clubhouse', '2-inch Wood Blinds', 'Vaulted Ceilings', '0', 'On-Site Laundry', '0', '0', 'Gated Community', 'TeeVee Cable Co', 'Fireplace', '0', '0', '0', 'valet', '0', 'Dogs', 'Cats'),
(2, 0, '', 19, '0', '0', '0', '0', '0', '0', '0', '0', 'Free Wifi', '0', 'AT&T', '0', '0', 'Storage Available', 'Reserved Parking', 'valet', '0', '0', '0'),
(3, 0, '', 20, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', '0', '0', '0', 'Time Warner', '0', '0', 'Storage Available', '0', 'valet', 'Sports Courts', '0', '0'),
(4, 0, '', 21, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', 'Business Center', '0', '0', 'AT&T', '0', '0', '0', '0', 'valet', '0', '0', '0'),
(5, 0, '', 22, '0', '0', 'Clubhouse', '0', '0', 'Pool', '0', '0', 'Free Wifi', '0', 'Time Warner', 'Fireplace', '0', '0', '0', 'valet', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `registration_codes`
--

CREATE TABLE `registration_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `usertype` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `account_expiration` bigint(13) NOT NULL,
  `code_expiration` int(13) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  UNIQUE KEY `id` (`id`,`code`),
  KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `registration_codes`
--

INSERT INTO `registration_codes` (`id`, `code`, `usertype`, `account_expiration`, `code_expiration`, `active`) VALUES
(1, 'locator', 'locator', 0, 0, 1),
(2, 'property', 'property', 0, 0, 1),
(3, 'oldcode', 'locator', 0, 0, 0),
(4, '446YVSMu', 'locator', 0, 1393628399, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `term` int(5) NOT NULL,
  `rent` int(5) NOT NULL,
  `deposit` int(5) DEFAULT NULL,
  `pet_rent` int(5) DEFAULT NULL,
  `pet_deposit` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`id`, `unit_id`, `term`, `rent`, `deposit`, `pet_rent`, `pet_deposit`) VALUES
(8, 4, 6, 500, 250, 0, 0),
(3, 2, 1, 0, 0, 0, 0),
(4, 3, 10, 0, 0, 0, 0),
(7, 4, 12, 12, 500, 1000, 1000),
(6, 4, 1, 0, 0, 0, 0),
(9, 4, 3, 700, 1000, 0, 250),
(10, 5, 12, 10000, 50000, 0, 0),
(11, 6, 12, 500, 250, 100, 250),
(15, 6, 6, 600, 300, 100, 250);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `beds` int(4) NOT NULL DEFAULT '1',
  `baths` int(4) NOT NULL DEFAULT '0',
  `size` smallint(6) NOT NULL,
  `direction` enum('N','NE','E','SE','S','SW','W','NW') COLLATE latin1_general_ci DEFAULT NULL,
  `date_available` bigint(13) DEFAULT NULL,
  `commission` int(4) DEFAULT NULL,
  `requirements` text COLLATE latin1_general_ci,
  `specials` text COLLATE latin1_general_ci,
  `washer` enum('none','connection','side by side','stacked') COLLATE latin1_general_ci DEFAULT NULL,
  `furnished` tinyint(1) DEFAULT NULL,
  `floor` smallint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `property_id`, `name`, `beds`, `baths`, `size`, `direction`, `date_available`, `commission`, `requirements`, `specials`, `washer`, `furnished`, `floor`) VALUES
(5, 15, 'Yet Another Test Unit', 86, 1, 15000, 'N', 1393542000, 10, 'No fat dudes.', '', 'stacked', 0, 37),
(2, 15, 'The Other Closet', 1, 0, 101, 'N', 2013, 100, 'nope', '', 'none', 1, 1),
(3, 15, 'It''s Like Closet Town Over Here', 1, 0, 57, 'SW', 2013, 0, 'Must like small spaces.', 'First year free!', 'stacked', 0, 1),
(4, 15, 'Surprise! A cavern!', 1, 0, 10, 'W', 2013, 0, '', '', 'none', 1, 1),
(6, 15, 'Big Fake Unit', 1, 1, 250, 'N', 1393628399, 0, '', '', 'none', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `expiration` int(13) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `display_name` varchar(128) NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `street` varchar(128) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `state` tinytext,
  `zip` varchar(10) DEFAULT NULL,
  `file_name` varchar(128) NOT NULL DEFAULT '/assets/img/profile/none.jpg',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `expiration`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `display_name`, `company`, `phone`, `street`, `city`, `state`, `zip`, `file_name`) VALUES
(1, '��', 'administrator', '59beecdf7fc966e2f17fd8f65a4a9aeb09d4a3d4', 0, '9462e8eee0', 'admin@admin.com', '', NULL, NULL, '9d029802e28cd9c768e8e62277c0df49ec65c48c', 1268889823, 1391749345, 0, 'Admin', 'istrator', '', 'ADMIN', '0', '', '', '', '', '/assets/img/profile/none.jpg'),
(2, 'L��6', 'johnny', 'd62fd2a8a4f98cd0524f2fc9553b876e8df47c4f', 1394146799, NULL, 'johnny@johnny.com', NULL, NULL, NULL, 'b221f49ab578223a1b799f7264cf3f1bb7b6f8c2', 1380515223, 1380515244, 1, 'Johnny', 'Bravo', '', 'none', '972-835-5000', '', '', '', '', '/assets/img/profile/none.jpg'),
(3, 'L��6', 'heisenberg', '51e3a3150ae4e89579d586e1058fc21cc2706a56', 0, NULL, 'heisenberg@example.com', NULL, NULL, NULL, NULL, 1380515501, 1380515501, 0, 'Heisenberg', 'Heisenberg', '', '', '123-456-0987', '', '', '', '', '/assets/img/profile/none.jpg'),
(4, 'L��6', 'pinkman', '64bf1d8284cdae2c48f0466dccfefabfdd31013f', 0, NULL, 'pinkman@example.com', NULL, NULL, NULL, NULL, 1380515717, 1380515717, 0, 'Jesse', 'Pinkman', '', 'PinkCo', '321-847-2840', '', '', '', '', '/assets/img/profile/none.jpg'),
(5, 'L��6', 'walterjr', '58d4e87de581463b8ddca339993b35d8c1f95f9c', 0, NULL, 'walterjr@example.com', NULL, NULL, NULL, 'b7cdef3459f844a75003349d9c50a4a373797fe3', 1380515972, 1380515993, 1, 'Walter', 'White', '', '', '391-382-4850', '', '', '', '', '/assets/img/profile/none.jpg'),
(6, 'L��6', 'skinnypete', 'b6e805de50e83053e1dfff64dd506e7c8880bfb2', 0, NULL, 'skinnyp@example.com', NULL, NULL, NULL, 'fceac7cce28bfd38cdc8b41e2601911d9f50d90c', 1380516602, 1380516617, 1, 'Skinny', 'Pete', '', '', '582-430-8740', '', '', '', '', '/assets/img/profile/none.jpg'),
(7, 'L��6', 'krazyeight', '71f82bcf7ec776e75f93f6d986a202fde88dfdea', 0, NULL, 'kr8zy@example.com', NULL, NULL, NULL, NULL, 1380516789, 1380516789, 1, 'Krazy', 'Eight', '', '', '471-480-2918', '', '', '', '', '/assets/img/profile/none.jpg'),
(8, 'L��6', 'username', '28409b3ce4adf8670247fa517e9c70a16ae5be36', 0, NULL, 'user@example.com', NULL, NULL, NULL, '62c1391963332c485e017d4d8c0c9a369248f8bc', 1380516909, 1391927075, 1, 'User', 'Name', 'John Doe', 'UserCo, Ltd.', '743-184-1235', '', '', '', '', '/assets/img/profile/none.jpg'),
(9, '���|', 'shadypines', '999184d6dfd5d0fc09aab85e3d8cafe50240175f', 0, NULL, 'shadypines@example.com', NULL, NULL, NULL, 'a1fb972ee913a079a9115435d9482481b775a74d', 1380556231, 1380739230, 1, 'Bob', 'Johnson', '', 'Shady Pines', '478-482-4095', '123 Four St.', 'Dallas', 'TX', '75000', '/assets/img/profile/none.jpg'),
(10, '���|', 'sandysands', '53b26389e63586bf155dd32d0891caaf711b1deb', 0, NULL, 'sandysands@example.com', NULL, NULL, NULL, 'b58fd258a400fb39bef2978e9c53e179b5d78b73', 1380556596, 1380641693, 1, 'Sandra', 'Sands', '', 'Sandy Sands', '734-128-5837', '432 One St.', 'Plano', 'TX', '75024', '/assets/img/profile/none.jpg'),
(15, 'L��6', 'fakeuser', 'f88d22f6490abb0b3c9190730e3bc69b9e1ba046', 0, NULL, 'fake@example.com', NULL, NULL, NULL, '774ea23116bfad7a044c1dbed291570555a82228', 1380955301, 1392066721, 1, 'Billy', 'Roberts', 'FakeTown', 'FakeTown', '123-456-7890', '4729 That St', 'Dallas', 'tx', '12345', '/assets/img/profile/none.jpg'),
(17, 'L��6', 'apartment', '15b071cf8fc3bcd01bc858e0d6bbb74af0828125', 0, NULL, 'apartment@example.com', NULL, NULL, NULL, '91b9dcbb33690dbc02004e8ab6afeaa0e1db7dac', 1386735290, 1386735290, 1, 'Apartmenty', 'McApartmentson', '', 'Apartment', '972-123-4567', '123 Some St.', 'Plano', 'tx', '75023', '/assets/img/profile/none.jpg'),
(18, 'L��6', 'test_apartment', '01eb2fb833f3fcee2b77c1dab4d00ce63ff61696', 0, NULL, 'test_apartment@example.com', NULL, NULL, NULL, 'eccfec2983a8ed4b9405d46b582f3ebb3270da63', 1386735986, 1386735986, 1, 'Test', 'Apartment', '', 'Test Apartment', '972-123-4567', '123 Some St.', 'Dallas', 'tx', '75123', '/assets/img/profile/none.jpg'),
(19, 'L��6', 'testProperty', '8d062551db7afb6d7428ee3f41104036b5a532b4', 0, NULL, 'testproperty2@example.com', NULL, NULL, NULL, '66b233c252ac4a38a06c15ab2a5ceec4ec3f12fb', 1386736479, 1386736479, 1, 'Test', 'Property', '', 'Test Property', '972-123-4567', '1456 Mockingbird Ln.', 'Dallas', 'tx', '75123', '/assets/img/profile/none.jpg'),
(20, 'L��6', 'testProperty3', 'b1cd36fb3444910279fb4ebcd385e8ede81d8d1b', 0, NULL, 'testproperty3@example.com', NULL, NULL, NULL, '1602d5ac104d26bb5ab848e489166421172d2a20', 1386737016, 1386737016, 1, 'Test', 'PropertyThree', '', 'Test Property 3', '972-485-1385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/none.jpg'),
(21, 'L��6', 'testProperty4', '86cc8797a2fecfd9f52d773c36e104b44a6c3269', 0, NULL, 'testproperty4@example.com', NULL, NULL, NULL, 'f4b0b5e1cf8bb0d9f8aac88ad7c18770dddbf2dd', 1386737753, 1386737753, 1, 'Test', 'PropertyFour', '', 'Test Property 4', '9724851385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/none.jpg'),
(22, 'L��6', 'testProperty5', '7fdafca5d680b923b571ca13bf6e5af1e13d636f', 0, NULL, 'testproperty5@example.com', NULL, NULL, NULL, 'a2ba38aa03aed550ccdf12de92ca928b61097104', 1386738850, 1386782473, 1, 'Test', 'PropertyFive', '', 'Test Property 5', '9724851385', '5729 Street Rd.', 'Plano', 'tx', '75024', '/assets/img/profile/0be2d990f7a23328c15da76a6acd07b6.jpg'),
(23, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'kronodude', 'd51c1f31eae2d762396fc008628ee55157145864', 0, NULL, 'owtytrof@gmail.com', NULL, NULL, NULL, '66bfb8595b5911e9b7cec66eab64486d6aaa2060', 1391226807, 1391229017, 1, 'Krono', 'Dude', 'KronoDude', 'KronoDude, LLC', '123-456-0987', NULL, NULL, NULL, NULL, '/assets/img/profile/none.jpg'),
(24, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'adminman', 'b4c7edb7a69f6bc9751a7d631fdaa529b185d585', 0, NULL, 'owtytrof@gmail.com', NULL, NULL, NULL, 'abc238d98ebea308784eff7eb5164d7e19b17652', 1391753485, 1391926965, 1, 'Admin', 'Adminman', 'Admin', NULL, NULL, NULL, NULL, NULL, NULL, '/assets/img/profile/none.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2),
(4, 3, 2),
(5, 4, 2),
(6, 5, 2),
(7, 6, 2),
(8, 7, 2),
(9, 8, 2),
(10, 9, 3),
(11, 10, 3),
(16, 15, 3),
(18, 17, 3),
(19, 18, 3),
(20, 19, 3),
(21, 20, 3),
(22, 21, 3),
(23, 22, 3),
(24, 23, 2),
(25, 24, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
